import pandas as pd
import yfinance as yf
#from yahoo_finance import YahooFinancials

tsla_df = yf.download('AAPL', 
                      start='1984-09-06', 
                      end='2021-05-20', 
                      progress=False)
tsla_df.to_csv('g.csv')